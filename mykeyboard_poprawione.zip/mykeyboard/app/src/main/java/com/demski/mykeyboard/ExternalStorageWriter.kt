package com.demski.mykeyboard

import android.content.Context
import android.os.Environment
import java.io.File
import java.io.FileOutputStream


class ExternalStorageWriter {

    fun write(text: String, context: Context) {
        val directory = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS).toString() + "/xd/")

        if (!directory.exists()) {
            directory.mkdirs()
        }

        val file = File(directory, "text.txt")
        file.createNewFile()
        var fileOutputStream: FileOutputStream? = null
        try {
            fileOutputStream = FileOutputStream(file)
            fileOutputStream.write(text.toByteArray())


        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            fileOutputStream?.flush()
            fileOutputStream?.close()
        }
    }
}
