package com.demski.mykeyboard

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.Keyboard
import android.media.MediaPlayer
import android.nfc.NfcManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

private const val CURRENT_KEYBOARD_MODE_TAG = "currentKeyboardMode"

class MainActivity : AppCompatActivity() {

    private val keyboards = mutableMapOf<KeyboardMode, Keyboard>()
    private var currentKeyboardMode = KeyboardMode.FIRST

    private val onKeyboardClick = { keyCode: Int ->
        val context = view_keyboard.context
        when (keyCode) {
            KeyEvent.KEYCODE_1 -> displayText()
            KeyEvent.KEYCODE_2 -> playSound()
            KeyEvent.KEYCODE_3 -> openCameraApp()
            KeyEvent.KEYCODE_4 -> saveTextFile()
            KeyEvent.KEYCODE_5 -> displayToast(context, "Toast tekst")
            KeyEvent.KEYCODE_6 -> changeKeyboardMode()
            KeyEvent.KEYCODE_7 -> checkNFCModuleStatus(context)
            KeyEvent.KEYCODE_8 -> changeNFCModuleStatus()
            KeyEvent.KEYCODE_9 -> vibrate()
            KeyEvent.KEYCODE_0 -> displayImage()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        restoreState(savedInstanceState)
        initKeyboard()
    }

    private fun restoreState(savedInstanceState: Bundle?) {
        savedInstanceState?.let {
            val keyboardModeIndex = savedInstanceState.getInt(CURRENT_KEYBOARD_MODE_TAG, KeyboardMode.FIRST.index)
            currentKeyboardMode = KeyboardMode.getByIndex(keyboardModeIndex)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("currentKeyboardMode", currentKeyboardMode.index)
        super.onSaveInstanceState(outState)
    }

    private fun initKeyboard() {
        keyboards[KeyboardMode.FIRST] = Keyboard(this, R.xml.keyboard_mode_first)
        keyboards[KeyboardMode.SECOND] = Keyboard(this, R.xml.keyboard_mode_second)

        val keyboardListener = KeyboardListener(onKeyboardClick)
        view_keyboard.keyboard = keyboards[currentKeyboardMode]
        view_keyboard.setOnKeyboardActionListener(keyboardListener)
        view_keyboard.isPreviewEnabled = false
    }

    private fun displayText() {
        view_text.setText(R.string.i_am_custom_keyboard)
    }


    private fun playSound() {
        val soundMediaPlayer = MediaPlayer.create(this, R.raw.sample)
        soundMediaPlayer.start()
    }

    private fun openCameraApp() {
        try {
            val intent = Intent()
            intent.action = MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA
            startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun saveTextFile() {
        ExternalStorageWriter().write("Krzysztof Demski", this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){
           // requestPermissions(arrayOf("Krzysztof Demski"){ Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000)
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1000)
        }

    }



    private fun displayToast(context: Context, text: String) {
        Toast.makeText(context, text, Toast.LENGTH_LONG).show()
    }

    private fun changeKeyboardMode() {
        currentKeyboardMode = currentKeyboardMode.next()
        view_keyboard.keyboard = keyboards[currentKeyboardMode]
    }

    private fun checkNFCModuleStatus(context: Context) {
        val manager = context.getSystemService(Context.NFC_SERVICE) as NfcManager
        val adapter = manager.defaultAdapter

        val nfcStatusText = if (adapter != null && adapter.isEnabled) {
            "NFC is enabled"
        } else {
            "NFC is disabled"
        }

        displayToast(context, nfcStatusText)
    }

    /*
        It is not possible to turn on/off NFC module status programmatically because of Android
        security.
     */
    private fun changeNFCModuleStatus() {
        startActivity(Intent(android.provider.Settings.ACTION_NFC_SETTINGS))
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(500)
        }
    }

    private fun displayImage() {
        view_image.visibility = View.VISIBLE
    }
}
