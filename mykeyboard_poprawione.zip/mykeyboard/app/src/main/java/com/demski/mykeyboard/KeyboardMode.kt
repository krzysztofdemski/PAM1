package com.demski.mykeyboard

enum class KeyboardMode(val index: Int) {
    FIRST(0),
    SECOND(1);

    fun next(): KeyboardMode {
        return if (this == FIRST) {
            SECOND
        } else {
            FIRST
        }
    }

    companion object {
        fun getByIndex(index: Int): KeyboardMode {
            return values().firstOrNull { it.index == index } ?: FIRST
        }
    }
}
