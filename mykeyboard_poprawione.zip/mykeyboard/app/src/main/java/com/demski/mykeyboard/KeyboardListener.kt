package com.demski.mykeyboard

import android.inputmethodservice.KeyboardView

class KeyboardListener(private val onKeyboardClick: (Int) -> Unit) : KeyboardView.OnKeyboardActionListener {
    override fun swipeRight() {}

    override fun onPress(primaryCode: Int) {}

    override fun onRelease(primaryCode: Int) {}

    override fun swipeLeft() {}

    override fun swipeUp() {}

    override fun swipeDown() {}

    override fun onText(text: CharSequence?) {}

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        onKeyboardClick.invoke(primaryCode)
    }
}